package com.example.yohan.translator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "Main Activity";
    EditText editText;
    TextView textView;
    Button btnTranslate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.ETTranslator);
        textView = findViewById(R.id.TVTranslator);
        btnTranslate= findViewById(R.id.btnTranslator);

        btnTranslate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String textToBeTranslated = editText.getText().toString();
                String languagePair = "en-si"; //English to French ("<source_language>-<target_language>")
                //Executing the translation function
                try {
                    Translate(textToBeTranslated,languagePair);
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }


            }
        });
    }

    void Translate(String textToBeTranslated,String languagePair) throws ExecutionException, InterruptedException {
        TranslatorBackgroundTask translatorBackgroundTask= new TranslatorBackgroundTask(getApplication());
        String translationResult = translatorBackgroundTask.execute(textToBeTranslated,languagePair).get(); // Returns the translated text as a String
        textView.setText(translationResult);// Logs the result in Android Monitor
    }
}
